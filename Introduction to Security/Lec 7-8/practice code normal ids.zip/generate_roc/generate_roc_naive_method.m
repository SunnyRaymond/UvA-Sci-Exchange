clear all
close all

% testset scores
score = [0.15 0.3 0.2 0.98 0.99 0.91 0.76 0.8 0.1 0.99 0.3 0.99 0.85 0.6 0.6 0.7 0.1 0.2 0.3 0.95 0.97 0.93 0 0.2 0.24 0.93 0.91 0.9];

% testset labels (ground truth)
% '1' stands for intrusion and '0' stands for 'no intrusion'
label = [1 1 1 0 0 0 0 0 0 1 0 1 0 0 0 0 0 0 0 1 1 1 0 0 0 1 1 1];

% compute the number of intrusions and number of normal datapoints in the testset
no_intrusions = sum(label);
no_normal = length(label) - no_intrusions;

% setting threshold range that will be examined to produce the ROC 
% here we will try m linearly increasing thresholds from 0 until 1
m = 20;
th_range = linspace(0, 1, m);

% the IDS will evaluate the testset using multiple thresholds
counter = 1;
TP = zeros(1,m);
FP = zeros(1,m);
for th = th_range
    
   % for any chosen threshold th, the IDS will compute TP, FP
   TP_count = 0;
   FP_count = 0;
   % by iterating over the testset scores and labels
   for i=1:length(score)
       
       % scores greater or equal than th cause an alert
       if score(i) >= th
           
           % if the alert corresponds to a true intrusion then increase
           % TP_count
           if label(i) == 1
               TP_count = TP_count + 1;
           end
           
           % if the alert does not corrspond to a true intrusion then increase
           % FP_count
           if label(i) == 0
               FP_count = FP_count + 1;
           end
           
       end
       
   end
    
   % compute the TP, FP ratios
   TP(counter) = TP_count/no_intrusions;
   FP(counter) = FP_count/no_normal;
   counter = counter + 1;
    
    
end

% plot the ROC
plot(FP, TP, '-o', 'LineWidth', 1.5);
xlabel('False Positive FP', 'FontSize', 13);
ylabel('True Positive TP', 'FontSize', 13);
title('ROC curve - naive computation', 'FontSize', 14);