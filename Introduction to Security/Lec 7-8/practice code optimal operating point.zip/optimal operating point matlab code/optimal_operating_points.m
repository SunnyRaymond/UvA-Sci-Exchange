clear all;
close all;

% Specify the operating points of the IDS in a ROC structure
roc.TP = [0.72 0.7 0.68 0.66 0.6];
roc.FP = [15*10^(-5) 10*10^(-5) 7*10^(-5) 5*10^(-5) 2*10^(-5)];

% Count the number of operating points in the specified curve
no_operating_points = length(roc.TP);

% Compute the true negative TN and the false negative FN
roc.TN = 1 - roc.FP;
roc.FN = 1 - roc.TP;

% Specify the cost ratio C 
% i.e. it is C times more expensive to have a false negative rather than a
% false positive
C = 20; 

% Specify the base rate B
B = 0.08;

% Analyze all the operating points of the IDS for the fixed cost ratio C 
% and fixed base rate B, using the formula from the decision tree
cost = zeros(no_operating_points, 1);
ids_always_respond = NaN(no_operating_points, 1);
ids_never_respond = NaN(no_operating_points, 1);
for i=1:no_operating_points
    % Compute the expected cost for all 4 decision branches
    
    % the expected cost of not responding when there is no alert 
    cost_noalert_noresponse = C * roc.FN(i) * B; 
    % the cost of responding when there is no alert 
    cost_noalert_response = roc.TN(i) * (1 - B);
    % the cost of not responding when there is an alert
    cost_alert_noresponse = C * roc.TP(i) * B;
    % the cost of responding when there is an alert 
    cost_alert_response = roc.FP(i) * (1 - B);
    
    % If the 'cost of responding when there is no alert' is less than the
    % 'cost of not responding when there is no alert' then the IDS will 
    % always respond 
    if cost_noalert_response < cost_noalert_noresponse 
        ids_always_respond(i) = 1;
    else
        ids_always_respond(i) = 0;
    end
    
    % If the 'cost of not responding when there is an alert' is less than 
    % the 'cost of responding when there is an alert' then the IDS will 
    % never respond 
    if cost_alert_noresponse < cost_alert_response
        ids_never_respond(i) = 1;
    else
        ids_never_respond(i) = 0;
    end
 
    % Compute the full cost with the formula derived from the decision tree
    cost(i) = min(cost_noalert_noresponse, cost_noalert_response) + ... 
                       min(cost_alert_noresponse, cost_alert_response); 
end

% Find the optimal operating point for fixed cost ratio C and fixed base
% rate B i.e. find the ROC point that minimizes the IDS cost
% Check first that the IDS responds regularly in this operating point 

[min_cost, min_index] = min(cost);
optimal_point.index = min_index;
optimal_point.cost = min_cost;
optimal_point.TP = roc.TP(min_index);
optimal_point.FP = roc.FP(min_index);
%--------------------------------------------------------------------------


% Analyze the same IDS for a various base rates B

% Generate linearly spaced base rates from 10^(-8) till 10^(-2)
B_vector = linspace(10^(-8), 10^(-2), 100);

% Generate logarithmically spaced base rates from 10^(-8) till 10^(-2)
B_vector = logspace(-8, -2, 100);

% Generate linearly-spaced base rates from 10^(-8) till 10^(-2)
B_vector = linspace(10^(-8), 10^(-2), 100);

% Count the number of base rates that will be analyzed
no_base_rates = length(B_vector);

% For all operating points in the ROC and for all base rates, compute the
% IDS cost, using the formula from the decision tree
expected_cost_matrix = zeros(no_operating_points, no_base_rates);
for i=1:no_operating_points
    for j=1:no_base_rates
        
        % Compute the expected cost
        expected_cost_matrix(i,j) = min(C * roc.FN(i) * B_vector(j), roc.TN(i) * (1 - B_vector(j))) + ... 
                                    min(C * roc.TP(i) * B_vector(j), roc.FP(i) * (1 - B_vector(j))); 
    
    end   
end

% Find the optimal operating point for every base rate analyzed 
for j=1:no_base_rates
    current_expected_cost = expected_cost_matrix(:,j);
    [min_cost, min_index] = min(current_expected_cost);
    optimal_point_vector.index(j) = min_index;
    optimal_point_vector.expected_cost(j) = min_cost;
    optimal_point_vector.TP(j) = roc.TP(min_index);
    optimal_point_vector.FP(j) = roc.FP(min_index);
end


%set(gca, 'YScale', 'log')
% plot(B_vector, expected_cost(2,:), 'o');

% plot the evolution of the expected cost (for the optimal point) as the 
% base rate increases
plot(log(B_vector), log(optimal_point_vector.expected_cost));
xlabel('Base Rate B (log scale)')
ylabel('Cost (log scale)')

% plot the cost of the optimal ROC point vs. the base rate
plot(log(B_vector), log(optimal_point_vector.expected_cost));
ylabel('IDS Cost (log scale)')
xlabel('Base Rate B (log scale)')

% plot(optimal_point_vector.index, '*')
% yaxis('afasd')

plot(log(B_vector), optimal_point_vector.expected_cost);
set(gca, 'YScale', 'log')

