% DES expansion function
function result = expansion(x)


end