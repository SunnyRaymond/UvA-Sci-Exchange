% DES inverse feistel permutation P^{-1}(c)
function result = inverse_feistel_permutation(x)


end