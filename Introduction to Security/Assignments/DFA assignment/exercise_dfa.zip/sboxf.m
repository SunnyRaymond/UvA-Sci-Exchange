% DES sbox function containing 8 sboxes
function sboxoutput = sbox(sboxinput, sbox_index)


end